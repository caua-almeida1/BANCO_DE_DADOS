<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteca Municipal</title>
    <link rel="stylesheet" href="./css/style.css">

</head>

<body>

    <header>
        <img src="./img/Biblioteca-Banner.png" alt="Biblioteca-Banner">
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="usuarios.php">Usuários</a></li>
                <li><a href="#">Livros</a></li>
                <li><a href="#">Empréstimo</a></li>
            </ul>
        </nav>
    </header>

    <main>
    <div></div>
    </main>

</body>

</html>